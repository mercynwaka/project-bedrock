import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        for record in event['Records']:
            # Get the object key (filename)
            key = record['s3']['object']['key']
            logger.info(f"Image received: {key}")
        
        return {
            'statusCode': 200,
            'body': json.dumps('Successfully processed S3 event')
        }
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        raise e
